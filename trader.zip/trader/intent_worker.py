"""
Trader Intent Observer (legacy)

This process is for DEBUG / telemetry only.

It listens to intent channels and logs what it sees. It does NOT execute trades
and does NOT dispatch to broker order channels unless explicitly enabled.

Why:
  We keep a single execution front-door: Trader HTTP /v1/intents.
  Redis subscribers should not be able to place trades by accident.

Enable legacy dispatch ONLY if you know you have a real downstream consumer:
  set ENABLE_LEGACY_DISPATCH=1
"""

from __future__ import annotations

import asyncio
import os
from typing import Dict, Any

from common.bus import subscribe, unpack, publish_async
from common import logging as log

COMPONENT = "trader.intent_router"

REFLEX_INSTANCE_ID = (os.getenv("REFLEX_INSTANCE_ID") or "default").strip()

def _resolve_channel(default_base: str) -> str:
    # Prefer explicit names; fall back to older envs.
    ch = (
        os.getenv("BOT_INTENT_CHANNEL")
        or os.getenv("PTI_INTENT_CHANNEL")
        or os.getenv("INTENT_CHANNEL")
        or os.getenv("ORDER_CHANNEL")
        or default_base
    ).strip()

    if "{instance_id}" in ch:
        ch = ch.format(instance_id=REFLEX_INSTANCE_ID)

    # enforce scoping for bare bases
    if ch in (default_base, "eval.intent", "eval.order_intent"):
        ch = f"{ch}.{REFLEX_INSTANCE_ID}"

    return ch

INTENT_CHANNEL = _resolve_channel("eval.intent")

ENABLE_LEGACY_DISPATCH = (os.getenv("ENABLE_LEGACY_DISPATCH") or "").strip() in ("1", "true", "yes", "on")

SIM_CHANNEL = (os.getenv("SIM_ORDER_CHANNEL") or "trader.sim.orders").strip()
ALPACA_CH = (os.getenv("ALPACA_ORDER_CHANNEL") or "trader.alpaca.orders").strip()

def _safe_decode(x):
    if isinstance(x, (bytes, bytearray, memoryview)):
        try:
            return bytes(x).decode("utf-8", "replace")
        except Exception:
            return f"<bytes len={len(x)}>"
    return x

async def _dispatch_legacy(intent: Dict[str, Any]):
    acct = (intent.get("account_id") or "SIM").lower()

    if acct in ("sim", "demo"):
        await publish_async(SIM_CHANNEL, intent)
        log.info(COMPONENT, "dispatch.sim", extra={"channel": SIM_CHANNEL, "symbol": intent.get("symbol"), "side": intent.get("side")})
    elif acct.startswith("alpaca"):
        await publish_async(ALPACA_CH, intent)
        log.info(COMPONENT, "dispatch.alpaca", extra={"channel": ALPACA_CH, "account_id": intent.get("account_id"), "symbol": intent.get("symbol"), "side": intent.get("side")})
    else:
        log.error(COMPONENT, "dispatch.unknown_account", extra={"account_id": intent.get("account_id"), "symbol": intent.get("symbol"), "side": intent.get("side")})

async def run():
    log.info(COMPONENT, "startup", extra={"sub": INTENT_CHANNEL, "legacy_dispatch": ENABLE_LEGACY_DISPATCH})
    ps = await subscribe(INTENT_CHANNEL)

    async for msg in ps.listen():  # redis pubsub
        if msg.get("type") != "message":
            continue

        ch = _safe_decode(msg.get("channel"))
        data = msg.get("data")
        data_len = len(data) if isinstance(data, (bytes, bytearray, memoryview)) else None
        log.info(COMPONENT, "received.intent", extra={"channel": ch, "data_len": data_len})

        try:
            envelope = unpack(msg["data"])
            intent = envelope.get("intent")
            meta = envelope.get("meta", {})
        except Exception:
            log.exception(COMPONENT, "bad_intent_payload", extra={"channel": ch, "data_len": data_len})
            continue

        if not intent:
            log.warning(COMPONENT, "no_intent_in_msg", extra={"envelope_keys": list(envelope.keys())})
            continue

        log.info(
            COMPONENT,
            "intent.observed",
            extra={
                "intent_id": intent.get("intent_id"),
                "symbol": intent.get("symbol"),
                "side": intent.get("side"),
                "strategy_id": intent.get("strategy_id"),
                "source": intent.get("source"),
                "strength": intent.get("strength"),
                "account_id": intent.get("account_id"),
            },
        )

        if ENABLE_LEGACY_DISPATCH:
            await _dispatch_legacy({**intent, "meta": meta})

if __name__ == "__main__":
    asyncio.run(run())
