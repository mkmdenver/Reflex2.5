starting outline:
DataHub (live + replay)

Evaluator (FTS/PTI/CTI)

Trader (order ingest, broker sync, SSE)

BrokerView (UI+event)

Redis + PG + Parquet