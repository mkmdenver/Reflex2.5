import asyncio
import msgpack
import os
from dataclasses import dataclass
from typing import Any, Dict

import redis.asyncio as redis

# Re-export the new IPC Bus for back-compat:
#   from common.bus import Bus
from common.ipc_bus import Bus, new_trace_id, ts_utc_ns, t_mono_ns  # type: ignore[import]  # noqa: E402

REDIS_URL = os.getenv("GARNET_URL", "redis://127.0.0.1:6379")

CHANNELS = {
    "ticks": "hub.ticks",
    "quotes": "hub.quotes",
    "raise": "eval.raisetier",
    "order": "eval.order_intent",
    "admin_flags": "admin.flags",
    # new channel for intraday “backfill today” requests
    "backfill": "hub.backfill",
}


def pack(d: Dict[str, Any]) -> bytes:
    return msgpack.packb(d, use_bin_type=True)


def unpack(b: bytes) -> Dict[str, Any]:
    return msgpack.unpackb(b, raw=False)


# ----------------------------------------------------------------------
# Core async primitives
# ----------------------------------------------------------------------


async def publisher():
    """Return an async Redis client."""
    return await redis.from_url(REDIS_URL, decode_responses=False)


async def subscribe(ch_name: str):
    """
    Subscribe to a single channel.
    Returns an async PubSub object; use:

        ps = await subscribe(CHANNELS["ticks"])
        async for msg in ps.listen():
            ...

    """
    r = await redis.from_url(REDIS_URL, decode_responses=False)
    p = r.pubsub()
    await p.subscribe(ch_name)
    return p

async def subscriber(ch_name: str):
    """Backwards-compatible alias; prefer subscribe()."""
    return await subscribe(ch_name)

async def publish_async(channel: str, payload: Dict[str, Any]) -> None:
    """
    Async publish helper for use inside async code.
    """
    r = await publisher()
    await r.publish(channel, pack(payload))


# ----------------------------------------------------------------------
# Synchronous wrapper for sync contexts (Flask handlers, etc.)
# ----------------------------------------------------------------------


def publish_sync(channel: str, payload: Dict[str, Any]) -> None:
    """
    Safe synchronous publish helper.

    Usage:
      - In sync code (e.g. Flask POST handler):
            publish_sync(CHANNELS["raise"], ev)

      - In async code, prefer `await publish_async(...)` instead.
    """

    async def _inner():
        r = await publisher()
        await r.publish(channel, pack(payload))

    try:
        # If there is already a running event loop, schedule into it.
        loop = asyncio.get_running_loop()
        asyncio.run_coroutine_threadsafe(_inner(), loop)
    except RuntimeError:
        # No running loop -> ok to create our own for this one shot.
        asyncio.run(_inner())


# ----------------------------------------------------------------------
# InternalEvent – normalized RT events used by LIVEAdapter
# ----------------------------------------------------------------------


@dataclass
class InternalEvent:
    """
    Normalized internal RT event.

    Used by datahub.adapters.live_adapter to represent:
      kind   : "trade" | "quote" | ...
      symbol : e.g. "AAPL"
      ts     : float (seconds or ms; hub only uses for ordering/metrics)
      payload: underlying raw/normalized dict from the feed.
    """

    kind: str
    symbol: str
    ts: float
    payload: Dict[str, Any]
