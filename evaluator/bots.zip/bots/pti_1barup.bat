REM @echo off
setlocal EnableExtensions

REM ---------------------------------------------------------------------------
REM KISS launcher for PTI_1barup
REM Assumption: this .bat lives in: <ROOT>\evaluator\bots\
REM You can run it from anywhere, including:
REM   c:\Projects\Reflex2.5\evaluator\bots>pti_1barup
REM ---------------------------------------------------------------------------

set "SCRIPT_DIR=%~dp0"

REM Compute repo root = two levels up from evaluator\bots\
for %%I in ("%SCRIPT_DIR%..\..") do set "ROOT=%%~fI"
set "ROOT=%ROOT%\"

REM BASE = ROOT without trailing backslash (for ROOT.venv fallback)
set "BASE=%ROOT%"
if "%BASE:~-1%"=="\" set "BASE=%BASE:~0,-1%"

REM Find venv python (prefer ROOT\.venv, fallback to ROOT.venv)
set "PY=%BASE%\.venv\Scripts\python.exe"
if not exist "%PY%" set "PY=%BASE%.venv\Scripts\python.exe"

set "PTI_REQUEST_TIER=1"
set "PTI_REQUEST_TIER_NAME=WATCH"

if not exist "%PY%" (
  echo [ERROR] Missing venv python. Tried:
  echo   "%BASE%\.venv\Scripts\python.exe"
  echo   "%BASE%.venv\Scripts\python.exe"
  exit /b 1
)

REM ----------------------------
REM PTI switches (edit as needed)
REM ----------------------------
set "PTI_FEED_MODE=LIVE"            
REM LIVE | REPLAY
set "PTI_INTENT_MODE=tee"          
REM send | record | tee | off

REM Universe control:
rem set "PTI_SYMBOLS_MODE=static"         
REM active_set | static
REM set "PTI_SYMBOLS=SPY,MSFT,SPHL,CJMB,AUID,MLEC,AHMA,CGTL,BNKK,RILY"    
rem set "PTI_SYMBOLS=SPY,MSFT"            
REM only used when static

REM Force PTI into active_set mode
set "PTI_SYMBOLS="
set "PTI_SYMBOLS_MODE=active_set"

REM Point PTI to the 1barup FTS feed
set "PTI_ACTIVE_SET_KEY=eval:fts_1barup:active"
set "PTI_FILTER_STREAM_CHANNEL=eval.1barup_filter_stream"


REM Where intents are recorded (record/tee)
set "PTI_INTENT_RECORD_PATH=%ROOT%evaluator\runs\pti_1barup\intents.jsonl"

set "PTI_ACCOUNT_ID=alpaca:paper"  
REM <- market open safety rail

set "PTI_1BAR_REQUEST_WARM_TIER=1"
set "PTI_1BAR_WARM_TIER_NAME=WARM"

set "PTI_INTENT_CHANNEL=eval.order_intent.liveA"
set "INTENT_CHANNEL=eval.order_intent.liveA"
set "ORDER_CHANNEL=eval.order_intent.liveA"


REM Optional: override bars channel explicitly (otherwise PTI uses *_PUB_LIVE/REPLAY)
REM set "PTI_BARS_CHANNEL=hub.bars1m.pub.replay"

echo [RUNNING] %ROOT%evaluator\bots\PTI_1barup.py
echo [ENV] ROOT=%ROOT%
echo [ENV] PY=%PY%
"%PY%" "%ROOT%evaluator\bots\PTI_1barup.py"
exit /b %errorlevel%
